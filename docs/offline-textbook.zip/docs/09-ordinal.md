# Modeling Ordinal Data

:::{.warning}
Nothing to see here (yet)! Stay tuned...
:::

